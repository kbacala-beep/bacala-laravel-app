@extends('layouts.app')

@section('title', 'Barangay Reports')

@section('content')
    <div class="container-fluid pt-4 px-4 pb-5">
        <h2 class="mb-4">Barangay Reports</h2>

        <a href="{{ route('reports.create') }}" class="btn btn-primary mb-3">Add New Report</a>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle border border-4 rounded overflow-hidden">
                <thead class="bg-secondary text-white">
                    <tr>
                        <th>#</th>
                        <th>Resident</th>
                        <th>Subject</th>
                        <th>Status</th>
                        <th>Submitted By</th>
                        <th>Attachments</th>
                        <th>Submitted</th>
                        <th class="col-2">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-secondary">
                    @forelse($reports as $index => $report)
                        <tr>
                            <!-- Consistent row numbering -->
                            <td>{{ $index + 1 }}</td>
                            <td><strong>{{ $report->resident_name }}</strong></td>
                            <td>{{ $report->subject }}</td>
                            <td>
                                <span class="badge 
                                    @if($report->status === 'Pending') bg-warning 
                                    @elseif($report->status === 'Resolved') bg-success 
                                    @else bg-light @endif">
                                    {{ $report->status }}
                                </span>
                            </td>
                            <td>
                                {{ $report->user->name ?? 'N/A' }}
                                <small class="text-muted">({{ $report->user->role->name ?? 'Resident' }})</small>
                            </td>
                            <td>
                                @if($report->attachments->count())
                                    <ul class="list-unstyled mb-0">
                                        @foreach($report->attachments as $attachment)
                                            <li>
                                                <a href="{{ asset('storage/' . $attachment->file_path) }}" target="_blank">
                                                    {{ basename($attachment->file_path) }}
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                @else
                                    <span class="text-muted">None</span>
                                @endif
                            </td>
                            <td>{{ $report->created_at->format('M d, Y') }}</td>
                            <td>
                                <a href="{{ route('reports.show', $report->id) }}" class="btn btn-info btn-sm">View</a>
                                <a href="{{ route('reports.edit', $report->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                <form action="{{ route('reports.destroy', $report->id) }}" method="POST"
                                    style="display:inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this report?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted">No reports found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection