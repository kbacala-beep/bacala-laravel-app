<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome | BrgyCIRS</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1b1b18, #2c2c2c);
            color: #fdfdfc;
            font-family: 'Segoe UI', sans-serif;
        }
        .hero {
            padding: 80px 20px;
        }
        .hero h1 {
            font-weight: 700;
            font-size: 3rem;
        }
        .hero p {
            font-size: 1.2rem;
            color: #ccc;
        }
        .btn-custom {
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        }
        footer {
            background-color: #222;
            color: #aaa;
        }
        footer a {
            color: #fdfdfc;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Hero Section -->
    <div class="container text-center hero my-auto">
        <h1 class="text-danger">Welcome to BrgyCIRS</h1>
        <p class="mb-4">Barangay Community Incident Reporting System</p>

        <!-- Buttons -->
        <div class="d-flex justify-content-center gap-3">
            <a href="{{ route('login') }}" class="btn btn-danger btn-custom">Login</a>
            <a href="{{ route('register') }}" class="btn btn-outline-light btn-custom">Register</a>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center py-3 mt-auto">
        &copy; Your Site Name, All Rights Reserved.
        <br>
        Designed By <a href="https://htmlcodex.com">HTML Codex</a> |
        Distributed By <a href="https://themewagon.com">ThemeWagon</a>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>