<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Report;
use App\Models\Attachment;

class DashboardController extends Controller
{
    public function index()
    {
        // Metrics
        $totalUsers = User::count();
        $totalReports = Report::count();
        $reportsToday = Report::whereDate('created_at', today())->count();
        $attachmentsCount = Attachment::count();

        // Recent reports
        $recentReports = Report::with('user')
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact(
            'totalUsers',
            'totalReports',
            'reportsToday',
            'attachmentsCount',
            'recentReports'
        ));
    }
}