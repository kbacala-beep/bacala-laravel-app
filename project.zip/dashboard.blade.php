@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <!-- Total Users -->
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-users fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Users</p>
                        <h6 class="mb-0">{{ $totalUsers }}</h6>
                    </div>
                </div>
            </div>

            <!-- Total Reports -->
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-file-alt fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Reports</p>
                        <h6 class="mb-0">{{ $totalReports }}</h6>
                    </div>
                </div>
            </div>

            <!-- Reports Today -->
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-calendar-day fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Reports Today</p>
                        <h6 class="mb-0">{{ $reportsToday }}</h6>
                    </div>
                </div>
            </div>

            <!-- Attachments -->
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-paperclip fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Attachments</p>
                        <h6 class="mb-0">{{ $attachmentsCount }}</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Reports -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Recent Reports</h6>
                <a href="{{ route('reports.index') }}">Show All</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-white">
                            <th scope="col"><input class="form-check-input" type="checkbox"></th>
                            <th scope="col">Date</th>
                            <th scope="col">Report ID</th>
                            <th scope="col">User</th>
                            <th scope="col">Title</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody class="pb-5">
                        @forelse($recentReports as $report)
                            <tr>
                                <td>{{ $report->created_at->format('d M Y') }}</td>
                                <td>#{{ $report->id }}</td>
                                <td>{{ $report->user->name ?? 'Unknown User' }}</td>
                                <td>{{ $report->title }}</td>
                                <td>{{ ucfirst($report->status) }}</td>
                                <td>
                                    <a class="btn btn-sm btn-primary" href="{{ route('reports.show', $report->id) }}">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center text-muted">No reports found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection