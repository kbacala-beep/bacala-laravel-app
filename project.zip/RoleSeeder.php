<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Insert default roles
        Role::create(['name' => 'Admin']);
        Role::create(['name' => 'Resident']);
    }
}