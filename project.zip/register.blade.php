<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register | BrgyCIRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for eye icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #1b1b18, #2c2c2c);
            color: #fdfdfc;
        }
        .card {
            background-color: #2c2c2c;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
        }
        .btn-custom {
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        }
        input[type="file"]::file-selector-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
        }
        input[type="file"]::file-selector-button:hover {
            background-color: #911c28ff;
            color: black;
        }
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(10%);
            color: #888;
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100">

    <div class="card p-4" style="width: 450px;">
        <div class="text-center mb-4">
            <h3 class="text-danger mt-2">Create Your BrgyCIRS Account</h3>
        </div>

        <!-- Error Messages -->
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data" onsubmit="return validateForm()">
            @csrf

            <div class="mb-3">
                <label for="name" class="form-label text-secondary"><strong>Full Name</strong></label>
                <input id="name" type="text" class="form-control text-white bg-dark" name="name" required autofocus>
            </div>

            <div class="mb-3">
                <label for="role" class="form-label text-secondary"><strong>Role</strong></label>
                <select id="role" name="role" class="form-select fst-italic text-white bg-dark" required>
                    <option value="Resident">Resident</option>
                    <option value="Admin">Admin</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="profile_photo" class="form-label text-secondary"><strong>Profile Picture</strong></label>
                <input id="profile_photo" type="file" class="form-control text-white bg-dark" name="profile_photo">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label text-secondary"><strong>Email Address</strong></label>
                <input id="email" type="email" class="form-control text-light bg-dark" name="email" required>
            </div>

            <div class="mb-3 position-relative">
                <label for="password" class="form-label text-secondary"><strong>Password</strong></label>
                <input id="password" type="password" class="form-control text-light bg-dark" name="password" required>
                <span class="password-toggle" onclick="togglePassword('password','toggleIcon1')">
                    <i id="toggleIcon1" class="fa-solid fa-eye"></i>
                </span>
            </div>

            <div class="mb-3 position-relative">
                <label for="password_confirmation" class="form-label text-secondary"><strong>Confirm Password</strong></label>
                <input id="password_confirmation" type="password" class="form-control text-light bg-dark" name="password_confirmation" required>
                <span class="password-toggle" onclick="togglePassword('password_confirmation','toggleIcon2')">
                    <i id="toggleIcon2" class="fa-solid fa-eye"></i>
                </span>
            </div>

            <button type="submit" class="btn btn-danger w-100 btn-custom">Register</button>
        </form>

        <div class="text-center text-secondary mt-3">
            <span>Already have an account?</span>
            <a href="{{ route('login') }}" class="text-danger">Login</a>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function togglePassword(fieldId, iconId) {
            const input = document.getElementById(fieldId);
            const icon = document.getElementById(iconId);
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);

            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        function validateForm() {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('password_confirmation').value;

            if (!name || !email || !password || !confirmPassword) {
                alert("All fields are required.");
                return false;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true; // allow submission
        }
    </script>

</body>
</html>