@extends('layouts.app')

@section('title', 'Report Details')

@section('content')
    <div class="container-fluid pt-4 pb-5 px-4">
        <h2 class="mb-4">Report Details</h2>

        <div class="card">
            <!-- Header -->
            <div class="card-header bg-secondary text-white">
                Report #{{ $report->id }}
            </div>

            <!-- Body -->
            <div class="card-body bg-secondary text-white">
                <h4 class="card-title">{{ $report->subject }}</h4>
                <p class="card-text mb-4 pb-3 ps-4">{{ $report->description }}</p>

                <p><strong>Resident Name:</strong> {{ $report->resident_name }}</p>
                <p><strong>Submitted By:</strong> {{ $report->user->name ?? 'N/A' }}
                    <small class="text-muted">({{ $report->user->role->name ?? 'Resident' }})</small>
                </p>
                <!-- Attachments -->
                <div class="mt-3">
                    <strong>Attachments:</strong>
                    @if($report->attachments->count())
                        <div class="row">
                            @foreach($report->attachments as $attachment)
                                <div class="col-md-3 mb-3">
                                    @if(Str::startsWith($attachment->file_type, 'image'))
                                        <!-- Show image directly -->
                                        <img src="{{ asset('storage/' . $attachment->file_path) }}" alt="Attachment"
                                            class="img-fluid rounded border border-light">
                                    @else
                                        <!-- Show link for non-image files -->
                                        <a href="{{ asset('storage/' . $attachment->file_path) }}" target="_blank">
                                            {{ basename($attachment->file_path) }}
                                        </a>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @else
                        <p class="text-muted">No attachments uploaded.</p>
                    @endif
                </div>
                <p><strong>Status:</strong>
                    <span class="badge 
                        @if($report->status === 'Pending') bg-warning 
                        @elseif($report->status === 'Resolved') bg-success 
                        @else bg-light @endif">
                        {{ $report->status }}
                    </span>
                </p>
                <p><strong>Date Created:</strong> {{ $report->created_at->format('M d, Y H:i') }}</p>
                <p><strong>Last Updated:</strong> {{ $report->updated_at->format('M d, Y H:i') }}</p>
            </div>

            <!-- Footer -->
            <div class="card-footer bg-secondary text-start">
                <a href="{{ route('reports.index') }}" class="btn btn-light">Back to Reports</a>
                <a href="{{ route('reports.edit', $report->id) }}" class="btn btn-success">Edit</a>
                <form action="{{ route('reports.destroy', $report->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger" onclick="return confirm('Delete this report?')">Delete</button>
                </form>
            </div>
        </div>
    </div>
@endsection