<?php

namespace App\Http\Controllers;

use App\Models\Report;
use App\Models\Attachment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReportsController extends Controller
{
    /**
     * Display a listing of the reports.
     */
    public function index()
    {
        // Fetch reports with user and attachments
        $reports = Report::with(['user', 'attachments'])->latest()->paginate(10);
        return view('reports.index', compact('reports'));
    }

    /**
     * Show the form for creating a new report.
     */
    public function create()
    {
        return view('reports.create');
    }

    /**
     * Store a newly created report in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'resident_name' => 'required|string|max:255',
            'subject'       => 'required|string|max:255',
            'description'   => 'required|string',
            'attachments.*' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        // Link report to logged-in user
        $report = Report::create([
            'user_id'       => Auth::id(),
            'resident_name' => $request->resident_name,
            'subject'       => $request->subject,
            'description'   => $request->description,
            'status'        => 'Pending',
        ]);

        // Handle attachments
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('attachments', 'public');
                Attachment::create([
                    'report_id' => $report->id,
                    'file_path' => $path,
                    'file_type' => $file->getClientMimeType(),
                ]);
            }
        }

        return redirect()->route('reports.index')
                         ->with('success', 'Report submitted successfully!');
    }

    /**
     * Display the specified report.
     */
    public function show(Report $report)
    {
        $report->load(['user', 'attachments']);
        return view('reports.show', compact('report'));
    }

    /**
     * Show the form for editing the specified report.
     */
    public function edit(Report $report)
    {
        return view('reports.edit', compact('report'));
    }

    /**
     * Update the specified report in storage.
     */
    public function update(Request $request, Report $report)
    {
        $request->validate([
            'resident_name' => 'required|string|max:255',
            'subject'       => 'required|string|max:255',
            'description'   => 'required|string',
            'status'        => 'required|string',
        ]);

        $report->update($request->all());

        return redirect()->route('reports.index')
                         ->with('success', 'Report updated successfully!');
    }

    /**
     * Remove the specified report from storage.
     */
    public function destroy(Report $report)
    {
        $report->delete();

        return redirect()->route('reports.index')
                         ->with('success', 'Report deleted successfully!');
    }
}