@extends('layouts.app')

@section('title', 'Edit Report')

@section('content')
<div class="container-fluid pt-4 px-4 pb-5">
    <h2>Edit Report</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('reports.update', $report->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <!-- Resident Name -->
        <div class="mb-3">
            <label for="resident_name" class="form-label"><strong>Resident Name</strong></label>
            <input type="text" name="resident_name" 
                   value="{{ old('resident_name', $report->resident_name) }}" 
                   class="form-control bg-secondary" required>
        </div>

        <!-- Subject -->
        <div class="mb-3">
            <label for="subject" class="form-label"><strong>Subject</strong></label>
            <input type="text" name="subject" 
                   value="{{ old('subject', $report->subject) }}" 
                   class="form-control bg-secondary" required>
        </div>

        <!-- Description -->
        <div class="mb-3">
            <label for="description" class="form-label"><strong>Description</strong></label>
            <textarea name="description" class="form-control bg-secondary" rows="4" required>{{ old('description', $report->description) }}</textarea>
        </div>

        <!-- Status -->
        <div class="mb-3">
            <label for="status" class="form-label"><strong>Status</strong></label>
            <select name="status" id="statusSelect"
                class="form-select bg-secondary border
                        {{ $report->status == 'Pending' ? 'border-warning' : '' }}
                        {{ $report->status == 'In Progress' ? 'border-light' : '' }}
                        {{ $report->status == 'Resolved' ? 'border-success' : '' }}"
                required>
                <option value="Pending" {{ $report->status == 'Pending' ? 'selected' : '' }}>Pending</option>
                <option value="In Progress" {{ $report->status == 'In Progress' ? 'selected' : '' }}>In Progress</option>
                <option value="Resolved" {{ $report->status == 'Resolved' ? 'selected' : '' }}>Resolved</option>
            </select>
        </div>

        <!-- Attachments -->
        <div class="mb-3">
            <label for="attachments" class="form-label"><strong>Attachments (optional)</strong></label>
            <input type="file" name="attachments[]" id="attachments" class="form-control bg-secondary" multiple>
            <small class="text-muted">You can upload multiple files (jpg, png, pdf).</small>

            @if($report->attachments->count())
                <div class="mt-2">
                    <strong>Existing Attachments:</strong>
                    <ul>
                        @foreach($report->attachments as $attachment)
                            <li>
                                <a href="{{ asset('storage/' . $attachment->file_path) }}" target="_blank">
                                    {{ basename($attachment->file_path) }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>

        <button type="submit" class="btn btn-success">Update Report</button>
        <a href="{{ route('reports.index') }}" class="btn btn-secondary">Cancel</a>
    </form>
</div>
@endsection