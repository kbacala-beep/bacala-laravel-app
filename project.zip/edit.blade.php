@extends('layouts.app')

@section('title', 'Profile')

@section('content')
<div class="container-fluid pt-4 px-4 pb-5">
    <h2 class="mb-4">My Profile</h2>

    <!-- Quick test line to confirm rendering -->
    <p>Hello, {{ $user->name }}</p>

    <div class="row">
        <div class="col-lg-8">

            <!-- Update Profile Information -->
            <div class="card mb-4">
                <div class="card-header bg-secondary text-white">
                    Update Profile Information
                </div>
                <div class="card-body bg-0">
                    @include('profile.partials.update-profile-information-form')
                </div>
            </div>

            <!-- Update Password -->
            <div class="card mb-4">
                <div class="card-header bg-secondary text-white">
                    Update Password
                </div>
                <div class="card-body bg-secondary">
                    @include('profile.partials.update-password-form')
                </div>
            </div>

            <!-- Delete Account -->
            <div class="card mb-4">
                <div class="card-header bg-danger text-white">
                    Delete Account
                </div>
                <div class="card-body bg-secondary">
                    @include('profile.partials.delete-user-form')
                </div>
            </div>

        </div>
    </div>
</div>
@endsection