<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | BrgyCIRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for eye icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #1b1b18, #2c2c2c);
            color: #fdfdfc;
        }
        .card {
            background-color: #2c2c2c;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
        }
        .btn-custom {
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: 500;
        }
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(10%);
            color: #888;
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-100">

    <div class="card p-4" style="width: 400px;">
        <div class="text-center mb-4">
            <h3 class="text-danger mt-2">Login to BrgyCIRS</h3>
        </div>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="mb-3">
                <label for="email" class="form-label text-secondary"><strong>Email Address</strong></label>
                <input id="email" type="email" class="form-control text-white bg-dark" name="email" required autofocus>
            </div>

            <div class="mb-3 position-relative">
                <label for="password" class="form-label text-secondary"><strong>Password</strong></label>
                <input id="password" type="password" class="form-control text-white bg-dark" name="password" required>
                <span class="password-toggle" onclick="togglePassword()">
                    <i id="toggleIcon" class="fa-solid fa-eye"></i>
                </span>
            </div>

            <div class="d-flex justify-content-between text-secondary align-items-center mb-3">
                <div>
                    <input type="checkbox" name="remember" id="remember">
                    <label for="remember">Remember Me</label>
                </div>
                <a href="{{ route('password.request') }}" class="text-light">Forgot Password?</a>
            </div>

            <button type="submit" class="btn btn-danger w-100 btn-custom">Login</button>
        </form>

        <div class="text-center mt-3 text-secondary">
            <span>Don't have an account?</span>
            <a href="{{ route('register') }}" class="text-danger">Register</a>
        </div>
    </div>

    <!-- Script: Show/Hide Password -->
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);

            // Toggle icon
            const icon = document.getElementById('toggleIcon');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>

</body>
</html>