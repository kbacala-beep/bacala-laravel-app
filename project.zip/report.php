<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'resident_name',
        'subject',
        'description',
        'status',
        'user_id', // link to the user who submitted the report
    ];

    /**
     * A report belongs to a user.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * A report can have many attachments.
     */
    public function attachments()
    {
        return $this->hasMany(Attachment::class);
    }
}